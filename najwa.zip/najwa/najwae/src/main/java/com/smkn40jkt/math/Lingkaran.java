package com.smkn40jkt.math;

public class Lingkaran {
    public static void luas(float jari) {
        double luas = Math.PI *jari*jari;
        System.out.println("Hasil Luas dari lingkaran berjari jari = "+jari+" = "+String.format("%.2f", luas));
    }
    public static void keliling(float diameter) {
        double kel = Math.PI *diameter;
        System.out.println("Hasil keliling dari lingkaran diameter = "+diameter+" = "+String.format("%.2f", kel));
    }
}
