package com.smkn40jkt.operator;

public class Penugasan {
    public static void tambah(int num1,int num2) {
         num1 += num2;
         System.out.println(num1);
    }
    public static void kurang(int num1,int num2) {
        num1 -= num2;
        System.out.println(num1);
    }
    public static void kali(int num1,int num2) {
        num1 *= num2;
        System.out.println(num1);
    }
    public static void bagi(int num1,int num2) {
        num1 /= num2;
        System.out.println(num1);
    }
}
