package com.smkn40jkt;

import com.smkn40jkt.math.Lingkaran;
import com.smkn40jkt.operator.*;

public class App 
{
    public static void main( String[] args )
    {
        // aritmatika
        // Aritmatika.tambah(50, 30);
        // Aritmatika.kurang(50, 33);
        // Aritmatika.kali(100, 2);
        // Aritmatika.bagi(50, 2);
        // Aritmatika.sisa(50, 40);

        // Penugasan
        // Penugasan.tambah(1,2);
        // Penugasan.kurang(5, 2);
        // Penugasan.kali(10, 2);
        // Penugasan.bagi(100, 20);

        // Rumus matematika lingkaran
        // Lingkaran.luas(10);
        Lingkaran.keliling(10);

    }
}
