package com.smkn40jkt.operator;
 
public class Aritmatika{
    public static void tambah(int num1,int num2) {
        System.out.println("Operator penjumlahan");
        int num3 = num1+num2;
        System.out.println(num3);
    }
    public static void kurang(int num1,int num2) {
        System.out.println("Operator pengurangan");
        int num3 = num1-num2;
        System.out.println(num3);
    }
    public static void kali(int num1,int num2) {
        System.out.println("Operator perkalian");
        int num3 = num1*num2;
        System.out.println(num3);
    }
    public static void bagi(int num1,int num2) {
        System.out.println("Operator pembagian");
        int num3 = num1/num2;
        System.out.println(num3);
    }
    public static void sisa(int num1,int num2) {
        System.out.println("Operator penjumlahan");
        int num3 = num1%num2;
        System.out.println(num3);
    }
}